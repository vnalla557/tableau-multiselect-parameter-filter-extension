(function () {
  let dashboardRef;
  let worksheetMap = {};

  tableau.extensions.initializeDialogAsync().then(() => {
    dashboardRef = tableau.extensions.dashboardContent.dashboard;

    const saveSettingsBtn = document.getElementById("save-settings");
    const addDropdownBtn = document.getElementById("add-dropdown");
    const filtersContainer = document.getElementById("filters-container");
    const filterHeaders = document.querySelector(".filter-headers");
    const emptyState = document.getElementById("empty-state");

    if (!saveSettingsBtn || !addDropdownBtn || !filtersContainer || !filterHeaders) {
      console.error("❌ Required DOM elements not found");
      return;
    }

    // Initially hide the headers
    filterHeaders.style.display = 'none';

    let allFilters = [];
    let allParameters = [];
    let savedConfig = tableau.extensions.settings.get("config");
    let configArray = savedConfig ? JSON.parse(savedConfig) : [];

    // Function to update headers visibility
    function updateHeadersVisibility() {
      const hasFilters = filtersContainer.children.length > 0;
      filterHeaders.style.display = hasFilters ? 'flex' : 'none';
      emptyState.style.display = hasFilters ? 'none' : 'block';
    }

    dashboardRef.getParametersAsync().then(parameters => {
      allParameters = parameters.map(p => p.name);

      let filterPromises = dashboardRef.worksheets.map(ws =>
        ws.getFiltersAsync().then(filters => {
          filters.forEach(f => {
            worksheetMap[f.fieldName] = ws.name;
            if (!allFilters.includes(f.fieldName)) {
              allFilters.push(f.fieldName);
            }
          });
        })
      );

      Promise.all(filterPromises).then(() => {
        configArray.forEach(cfg => {
          addRow(cfg.filter, cfg.param, cfg.allValues);
        });

        updateHeadersVisibility();

        addDropdownBtn.disabled = false;
        addDropdownBtn.addEventListener("click", () => {
          addRow();
          updateHeadersVisibility();
        });

        saveSettingsBtn.disabled = false;
        saveSettingsBtn.addEventListener("click", () => {
          console.log("✅ Save button clicked");

          const rows = filtersContainer.querySelectorAll(".dropdown-wrapper");
          const newConfig = [];

          rows.forEach(row => {
            const filter = row.querySelector(".key-dropdown").value;
            const param = row.querySelector(".value-dropdown").value;
            const checkbox = row.querySelector("input[type=checkbox]")?.checked || false;

            newConfig.push({
              filter,
              param,
              sheet: worksheetMap[filter],
              allValues: checkbox
            });
          });

          tableau.extensions.settings.set("config", JSON.stringify(newConfig));
          tableau.extensions.settings.saveAsync().then(() => {
            tableau.extensions.ui.closeDialog("Settings saved");
          });
        });
      });
    });

    function addRow(selectedFilter = "", selectedParam = "", allValues = false) {
      const wrapper = document.createElement("div");
      wrapper.className = "dropdown-wrapper";

      const createDropdown = (className, options, selected) => {
        const select = document.createElement("select");
        select.className = className;

        const defaultOption = document.createElement("option");
        defaultOption.textContent = "Select an option";
        defaultOption.value = "";
        select.appendChild(defaultOption);

        options.forEach(opt => {
          const o = document.createElement("option");
          o.value = opt;
          o.textContent = opt;
          select.appendChild(o);
        });

        select.value = selected;
        return select;
      };

      const keyWrapper = document.createElement("div");
      keyWrapper.className = "dropdown-group";
      keyWrapper.appendChild(createDropdown("key-dropdown", allFilters, selectedFilter));

      const valWrapper = document.createElement("div");
      valWrapper.className = "dropdown-group";
      valWrapper.appendChild(createDropdown("value-dropdown", allParameters, selectedParam));

      const deleteBtn = document.createElement("button");
      deleteBtn.className = "delete-button";
      deleteBtn.textContent = "×";
      deleteBtn.addEventListener("click", () => {
        wrapper.remove();
        updateHeadersVisibility();
      });

      wrapper.appendChild(keyWrapper);
      wrapper.appendChild(valWrapper);
      wrapper.appendChild(deleteBtn);

      filtersContainer.appendChild(wrapper);
    }
  });
})();
